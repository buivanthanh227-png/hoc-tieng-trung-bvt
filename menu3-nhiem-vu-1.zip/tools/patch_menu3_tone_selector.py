#!/usr/bin/env python3
"""Install the Menu 18-style exact syllable/tone selector for Menu 3 only."""
from pathlib import Path
import sys

MARKER = "MENU3_MENU18_TONE_POSITION_SELECTOR_V1"
SELECTOR = r"""
/* MENU3_MENU18_TONE_POSITION_SELECTOR_V1 */
function pinyin18Menu3IsStrictSyllable(value){
 return /^(?:a|ai|an|ang|ao|ba|bai|ban|bang|bao|bei|ben|beng|bi|bian|biao|bie|bin|bing|bo|bu|ca|cai|can|cang|cao|ce|cen|ceng|cha|chai|chan|chang|chao|che|chen|cheng|chi|chong|chou|chu|chua|chuai|chuan|chuang|chui|chun|chuo|ci|cong|cou|cu|cuan|cui|cun|cuo|da|dai|dan|dang|dao|de|dei|den|deng|di|dia|dian|diao|die|ding|diu|dong|dou|du|duan|dui|dun|duo|e|ei|en|eng|er|fa|fan|fang|fei|fen|feng|fo|fou|fu|ga|gai|gan|gang|gao|ge|gei|gen|geng|gong|gou|gu|gua|guai|guan|guang|gui|gun|guo|ha|hai|han|hang|hao|he|hei|hen|heng|hong|hou|hu|hua|huai|huan|huang|hui|hun|huo|ji|jia|jian|jiang|jiao|jie|jin|jing|jiong|jiu|ju|juan|jue|jun|ka|kai|kan|kang|kao|ke|kei|ken|keng|kong|kou|ku|kua|kuai|kuan|kuang|kui|kun|kuo|la|lai|lan|lang|lao|le|lei|leng|li|lia|lian|liang|liao|lie|lin|ling|liu|lo|long|lou|lu|luan|lue|lun|luo|ma|mai|man|mang|mao|me|mei|men|meng|mi|mian|miao|mie|min|ming|miu|mo|mou|mu|na|nai|nan|nang|nao|ne|nei|nen|neng|ni|nian|niang|niao|nie|nin|ning|niu|nong|nou|nu|nue|nuan|nuo|o|ou|pa|pai|pan|pang|pao|pei|pen|peng|pi|pian|piao|pie|pin|ping|po|pou|pu|qi|qia|qian|qiang|qiao|qie|qin|qing|qiong|qiu|qu|quan|que|qun|ran|rang|rao|re|ren|reng|ri|rong|rou|ru|rua|ruan|rui|run|ruo|sa|sai|san|sang|sao|se|sen|seng|sha|shai|shan|shang|shao|she|shei|shen|sheng|shi|shou|shu|shua|shuai|shuan|shuang|shui|shun|shuo|si|song|sou|su|suan|sui|sun|suo|ta|tai|tan|tang|tao|te|tei|teng|ti|tian|tiao|tie|ting|tong|tou|tu|tuan|tui|tun|tuo|wa|wai|wan|wang|wei|wen|weng|wo|wu|xi|xia|xian|xiang|xiao|xie|xin|xing|xiong|xiu|xu|xuan|xue|xun|ya|yan|yang|yao|ye|yi|yin|ying|yo|yong|you|yu|yuan|yue|yun|za|zai|zan|zang|zao|ze|zei|zen|zeng|zha|zhai|zhan|zhang|zhao|zhe|zhei|zhen|zheng|zhi|zhong|zhou|zhu|zhua|zhuai|zhuan|zhuang|zhui|zhun|zhuo|zi|zong|zou|zu|zuan|zui|zun|zuo|m|n|ng|hm|hng)$/.test(String(value||''));
}
function pinyin18Menu3ShortestPaths(raw, syllables) {
 const token=typeof pinyin18Key==='function'?pinyin18Key(raw):String(raw||'').toLowerCase().replace(/[^a-z]/g,'');
 if(!token||!syllables||!syllables.size)return [];
 const strict=new Set();
 for(const item of syllables){
  const key=typeof pinyin18Key==='function'?pinyin18Key(item):String(item||'');
  if(pinyin18Menu3IsStrictSyllable(key))strict.add(key);
 }
 if(!strict.size)return [];
 const memo=new Array(token.length+1);
 memo[token.length]=[[]];
 for(let start=token.length-1;start>=0;start--){
  let bestLen=Infinity,best=[];
  for(let end=start+1;end<=Math.min(token.length,start+6);end++){
   const part=token.slice(start,end),tails=memo[end];
   if(!strict.has(part)||!tails||!tails.length)continue;
   for(const tail of tails){
    const path=[part].concat(tail);
    if(path.length<bestLen){bestLen=path.length;best=[path];}
    else if(path.length===bestLen&&best.length<16)best.push(path);
   }
  }
  memo[start]=best;
 }
 return memo[0]||[];
}
function pinyin18SelectToneDiverse(candidates, raw, limit=30) {
 const inputTokens=String(raw||'').trim().split(/[\s,，、;；]+/).filter(Boolean);
 if(!inputTokens.length)return [];
 const index=typeof getPinyin18SourceIndex==='function'?getPinyin18SourceIndex():null;
 const syllables=index?.syllables;
 if(!syllables||!syllables.size)return [];
 let expected=[{keys:[],tones:[]}],hasCompact=false;
 for(const rawToken of inputTokens){
  const key=pinyin18Key(rawToken);
  if(!key)return [];
  const isSyllable=pinyin18Menu3IsStrictSyllable(key);
  const splits=isSyllable?[[key]]:pinyin18Menu3ShortestPaths(rawToken,syllables);
  if(!splits.length)return [];
  if(!isSyllable)hasCompact=true;
  const requestedTone=isSyllable?pinyin18ToneFromInput(rawToken):null;
  const next=[];
  for(const prior of expected)for(const split of splits){
   next.push({keys:prior.keys.concat(split),tones:prior.tones.concat(split.map((_,i)=>i===0?requestedTone:null))});
   if(next.length>=48)break;
  }
  expected=next.slice(0,48);
 }
 const byBase=new Map();
 for(const path of expected){
  const base=path.keys.join(' ');
  if(!byBase.has(base))byBase.set(base,[]);
  byBase.get(base).push(path);
 }
 const rows=(Array.isArray(candidates)?candidates:[]).map(item=>{
  const tokens=String(item?.py||'').trim().split(/\s+/).filter(Boolean);
  if(!item?.zh||!tokens.length)return null;
  const base=tokens.map(pinyin18Key).join(' '),paths=byBase.get(base);
  if(!paths)return null;
  const match=paths.find(path=>path.tones.every((tone,i)=>tone===null||pinyin18ToneFromInput(tokens[i])===tone));
  if(!match)return null;
  let priority=Number(item.priority)||Number(item.score)||0;
  const compact=inputTokens.map(pinyin18Key).join('');
  const preferred={jintian:'今天',zuotian:'昨天',xihuan:'喜欢'};
  if(preferred[compact]===String(item.zh))priority+=1000000;
  return {item,tokens,priority,tones:match.tones,base};
 }).filter(Boolean);
 if(!rows.length)return [];
 let ranked=rows;
 if(hasCompact){
  const groups=new Map();
  for(const row of ranked){if(!groups.has(row.base))groups.set(row.base,[]);groups.get(row.base).push(row);}
  ranked=[...groups.values()].sort((a,b)=>{
   const ap=Math.max(...a.map(x=>x.priority)),bp=Math.max(...b.map(x=>x.priority));
   if(ap!==bp)return bp-ap;
   return b.length-a.length;
  })[0];
 }
 ranked.sort((a,b)=>b.priority-a.priority||String(a.item.zh).localeCompare(String(b.item.zh),'zh-CN'));
 const baseline=ranked[0];
 const baseTones=baseline.tokens.map(token=>pinyin18ToneFromInput(token)||5);
 ranked=ranked.filter(row=>{
  let changed=0;
  for(let i=0;i<baseTones.length;i++){
   const tone=pinyin18ToneFromInput(row.tokens[i])||5;
   if(tone!==baseTones[i]&&++changed>1)return false;
  }
  return true;
 });
 const selected=[],seen=new Set();
 const add=row=>{
  if(!row||selected.length>=limit)return;
  const id=String(row.item.zh)+'|'+String(row.item.py);
  if(seen.has(id))return;seen.add(id);selected.push(row);
 };
 add(baseline);
 const positions=baseline.tokens.map((_,index)=>{
  const tones=new Map();
  for(const row of ranked){
   const tone=pinyin18ToneFromInput(row.tokens[index])||5;
   const prior=tones.get(tone);
   if(!prior||row.priority>prior.priority)tones.set(tone,row);
  }
  return {index,tones};
 });
 positions.filter(p=>p.tones.size>1&&baseline.tones[p.index]===null)
  .sort((a,b)=>b.tones.size-a.tones.size||a.index-b.index)
  .forEach(p=>[...p.tones.keys()].sort((a,b)=>a-b).forEach(tone=>add(p.tones.get(tone))));
 return selected.map(row=>row.item);
}
window.pinyin18SelectToneDiverse=pinyin18SelectToneDiverse;
"""

def main():
    target = Path(sys.argv[1] if len(sys.argv) > 1 else "index.html")
    html = target.read_text(encoding="utf-8")
    fresh = SELECTOR.strip()
    start = html.find("/* MENU3_MENU18_TONE_POSITION_SELECTOR_V1 */")
    end_token = "window.pinyin18SelectToneDiverse=pinyin18SelectToneDiverse;"
    end = html.find(end_token, start if start >= 0 else 0)
    if start >= 0 and end >= 0:
        end += len(end_token)
        current = html[start:end]
        if current == fresh:
            print("Menu 3 Menu 18 tone-position selector already installed and corrected.")
            return
        html = html[:start] + fresh + html[end:]
        target.write_text(html, encoding="utf-8", newline="\n")
        print("Updated Menu 3 selector: strict syllables only, no displayed spacing from preferredPinyin.")
        return
    if "function pinyin18ToneFromInput(value){" not in html or "function pinyin18Key(value){" not in html:
        raise SystemExit("Menu 18 Pinyin tone/key helpers are missing; refusing to install an incompatible selector.")
    anchor = "function pinyinToChineseCandidates(raw){"
    if html.count(anchor) != 1:
        raise SystemExit("Expected exactly one Pinyin candidate mapper for Menu 3 selector insertion.")
    html = html.replace(anchor, fresh + "\n" + anchor, 1)
    target.write_text(html, encoding="utf-8", newline="\n")
    print("Menu 3 Menu 18-derived syllable/tone-position selector: PASS")

if __name__ == "__main__":
    main()
