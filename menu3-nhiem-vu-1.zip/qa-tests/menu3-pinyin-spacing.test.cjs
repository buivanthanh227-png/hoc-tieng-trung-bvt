'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const runtime = fs.readFileSync(path.join(root, 'menu3-pinyin-fix-v42.10.23.js'), 'utf8');
const dictionaryMatch = html.match(/<script id="embedded-cvdict-data"[^>]*>([\s\S]*?)<\/script>/);
assert.ok(dictionaryMatch, 'Embedded CVDICT data must be present');
const dictionary = JSON.parse(dictionaryMatch[1]);

function extractStatement(marker) {
  const start = html.indexOf(marker);
  assert.ok(start >= 0, marker);
  let quote = '', escape = false;
  for (let i = start; i < html.length; i++) {
    const ch = html[i];
    if (quote) {
      if (escape) { escape = false; continue; }
      if (ch === '\\') { escape = true; continue; }
      if (ch === quote) quote = '';
      continue;
    }
    if (ch === "'" || ch === '"' || ch === '`') { quote = ch; continue; }
    if (ch === ';') return html.slice(start, i + 1);
  }
  throw new Error('Unterminated ' + marker);
}

const algorithmStart = html.indexOf('function pinyin18ToneFromInput(value){');
const algorithmEnd = html.indexOf('async function machineTranslate(text,source,target){', algorithmStart);
assert.ok(algorithmStart >= 0 && algorithmEnd > algorithmStart);
const formatStart = runtime.indexOf('function menu3SourceLetters(value){');
const formatEnd = runtime.indexOf('window.formatByInputSpacing=formatByInputSpacing;');
assert.ok(formatStart >= 0 && formatEnd > formatStart);

const context = {
  dictionary,
  buildSeed: () => dictionary,
  pinyinForChinese: () => '',
  MENU18_VERIFIED_SENTENCES: [],
  OFFLINE_SENTENCE_TRANSLATIONS: {},
  console
};
context.window = context;
vm.createContext(context);
vm.runInContext(
  [extractStatement('const seed'), extractStatement('const extraSeed'), extractStatement('const sentenceDeck'), html.slice(algorithmStart, algorithmEnd)].join('\n'),
  context,
  { timeout: 20000 }
);
vm.runInContext(runtime.slice(formatStart, formatEnd + 'window.formatByInputSpacing=formatByInputSpacing;'.length), context, { timeout: 10000 });

function finalPinyin(query) {
  const selected = context.pinyin18SelectToneDiverse(context.pinyinToChineseCandidates(query), query, 30);
  if (selected.length) {
    const shown = context.formatByInputSpacing(query, selected[0].py);
    assert.equal(typeof shown, 'string', query + ' must produce a final Pinyin string');
    return shown;
  }
  const composed = context.composePinyinSentence3x(query);
  const options = composed.status === 'ok' ? [composed] : (composed.options || []);
  assert.ok(options.length, query + ' must come from dictionary-backed composition');
  return options.map(item => {
    const shown = context.formatByInputSpacing(query, item.py);
    assert.equal(typeof shown, 'string', query + ' / ' + item.zh);
    return { zh: item.zh, py: shown };
  });
}

test('final Pinyin keeps the user boundary for zuotian and does not emit zuo ti an', () => {
  const shown = finalPinyin('zuotian');
  assert.equal(shown, 'zuótiān');
  assert.equal(shown.includes(' '), false);
  assert.notEqual(shown, 'zuo ti an');
  assert.equal(context.formatByInputSpacing('zuotian', 'zuǒ tí àn'), 'zuǒtíàn');
  assert.equal(context.formatByInputSpacing('zuotian', 'zuó ti ān').includes(' '), false);
});

test('spaced and compact inputs keep exactly the spaces the user typed', () => {
  assert.equal(finalPinyin('zuo tian'), 'zuó tiān');
  assert.equal(finalPinyin('jintian'), 'jīntiān');
  assert.equal(finalPinyin('xihuan'), 'xǐhuan');
  assert.equal(finalPinyin('xi huan'), 'xǐ huan');
});

test('a sentence keeps the original word groups instead of syllable spaces', () => {
  const options = finalPinyin('jintian laoshi qing he cha');
  assert.ok(Array.isArray(options));
  assert.ok(options.some(item => item.py === 'jīntiān lǎoshī qǐng hē chá'));
  for (const item of options) {
    assert.deepEqual(item.py.split(' '), ['jīntiān', 'lǎoshī', 'qǐng', item.py.split(' ')[3], 'chá']);
    assert.equal(item.py.includes('jīn tiān'), false);
    assert.equal(item.py.includes('lǎo shī'), false);
  }
});

test('punctuation, repeated spaces and original capitalization survive tone marking', () => {
  assert.equal(context.formatByInputSpacing('zuotian,  jintian.', 'zuó tiān jīn tiān'), 'zuótiān,  jīntiān.');
  assert.equal(context.formatByInputSpacing('ZuoTian', 'zuó tiān'), 'ZuóTiān');
  assert.equal(context.formatByInputSpacing('ZUOTIAN', 'zuó tiān'), 'ZUÓTIĀN');
  assert.equal(finalPinyin('ZuoTian'), 'ZuóTiān');
  assert.equal(context.formatByInputSpacing('jintian,  laoshi.', 'jīntiān lǎoshī'), 'jīntiān,  lǎoshī.');
});

test('tone marks are not invented when the source reading does not align', () => {
  assert.equal(context.formatByInputSpacing('zuotian', 'ni hao'), null);
  assert.equal(context.formatByInputSpacing('zuotian', ''), null);
});

test('internal segmentation of zuotian is zuo+tian, never zuo+ti+an', () => {
  const syllables = context.getPinyin18SourceIndex().syllables;
  assert.equal(syllables.has('xihuan'), true, 'sentence deck still pollutes the raw syllable inventory');
  assert.equal(context.pinyin18Menu3IsStrictSyllable('xihuan'), false);
  assert.equal(context.pinyin18Menu3IsStrictSyllable('t'), false);
  const paths = context.pinyin18Menu3ShortestPaths('zuotian', syllables);
  assert.equal(JSON.stringify(paths), JSON.stringify([['zuo', 'tian']]));
  assert.equal(paths.some(path => path.join(' ') === 'zuo ti an'), false);
});
